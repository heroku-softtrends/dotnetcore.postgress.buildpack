**To delete an ACM certificate from your account**

The following ``delete-certificate`` command deletes the certificate with the specified ARN::

  aws acm delete-certificate --certificate-arn arn:aws:acm:us-east-1:123456789012:certificate/12345678-1234-1234-1234-123456789012